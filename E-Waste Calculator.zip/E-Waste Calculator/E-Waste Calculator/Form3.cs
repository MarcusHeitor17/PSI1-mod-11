﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Waste_Calculator
{

    public partial class Form3 : Form
    {
        
        public static double PlasticoG;
        public static double AluminioG;
        public static double CobreG;
        public static double eWasteG;
        public static double CO2G;




        public Form3()
        {
            InitializeComponent();
            PlasticoLBL.Text = ("" + (int)PlasticoG + " g");
            CobreLBL.Text = ("" + (int)AluminioG + " g");
            AluminioLBL.Text = ("" + (int)CobreG + " g");
            RespostaLBL.Text = ("Você coletou um total de " + (int)eWasteG + " kg de lixo eletrônico. \n Reciclado corretamente, isso economiza até " + (int)CO2G + "kg de CO2 equivalente.");

        }




        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var Form1 = new Form1();
            this.Hide();
            Form1.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }


        private void Resposta_Click(object sender, EventArgs e)
        {

        }
    }
}
