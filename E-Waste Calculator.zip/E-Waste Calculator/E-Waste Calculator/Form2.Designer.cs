﻿
namespace E_Waste_Calculator
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.numericUpDownOtherSTE = new System.Windows.Forms.NumericUpDown();
            this.label31 = new System.Windows.Forms.Label();
            this.numericUpDownRouter = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.numericUpDownPrinter = new System.Windows.Forms.NumericUpDown();
            this.label29 = new System.Windows.Forms.Label();
            this.numericUpDownMobilePhone = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.numericUpDownLaptop = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.numericUpDownLamp = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.numericUpDownLCDTV = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.numericUpDownCRTTV = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.numericUpDownAlkaline = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.numericUpDownNickelbased = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.numericUpDownLithiumionBatteries = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.numericUpDownClothesDryer = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.numericUpDownWashingmachine = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.numericUpDownDishwasher = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.numericUpDownAirCond = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.numericUpDownWBoiler = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownFreezer = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.numericUpDownMicrowave = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.numericUpDownOtherSE = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownPersonalCare = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDownHeatAndTemp = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownKitchenApplience = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOtherSTE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRouter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPrinter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMobilePhone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLaptop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLamp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLCDTV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCRTTV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlkaline)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNickelbased)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLithiumionBatteries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownClothesDryer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWashingmachine)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDishwasher)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAirCond)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWBoiler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFreezer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMicrowave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOtherSE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPersonalCare)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHeatAndTemp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownKitchenApplience)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // numericUpDownOtherSTE
            // 
            this.numericUpDownOtherSTE.Location = new System.Drawing.Point(474, 2139);
            this.numericUpDownOtherSTE.Name = "numericUpDownOtherSTE";
            this.numericUpDownOtherSTE.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownOtherSTE.TabIndex = 177;
            this.numericUpDownOtherSTE.ValueChanged += new System.EventHandler(this.numericUpDownOtherSTE_ValueChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(501, 2005);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(46, 18);
            this.label31.TabIndex = 176;
            this.label31.Text = "Other";
            // 
            // numericUpDownRouter
            // 
            this.numericUpDownRouter.Location = new System.Drawing.Point(239, 2139);
            this.numericUpDownRouter.Name = "numericUpDownRouter";
            this.numericUpDownRouter.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownRouter.TabIndex = 174;
            this.numericUpDownRouter.ValueChanged += new System.EventHandler(this.numericUpDownRouter_ValueChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(263, 2005);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 18);
            this.label30.TabIndex = 173;
            this.label30.Text = "Router";
            // 
            // numericUpDownPrinter
            // 
            this.numericUpDownPrinter.Location = new System.Drawing.Point(584, 1958);
            this.numericUpDownPrinter.Name = "numericUpDownPrinter";
            this.numericUpDownPrinter.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownPrinter.TabIndex = 171;
            this.numericUpDownPrinter.ValueChanged += new System.EventHandler(this.numericUpDownPrinter_ValueChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(608, 1824);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(54, 18);
            this.label29.TabIndex = 170;
            this.label29.Text = "Printer";
            // 
            // numericUpDownMobilePhone
            // 
            this.numericUpDownMobilePhone.Location = new System.Drawing.Point(123, 1958);
            this.numericUpDownMobilePhone.Name = "numericUpDownMobilePhone";
            this.numericUpDownMobilePhone.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownMobilePhone.TabIndex = 168;
            this.numericUpDownMobilePhone.ValueChanged += new System.EventHandler(this.numericUpDownMobilePhone_ValueChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(122, 1824);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(104, 18);
            this.label28.TabIndex = 167;
            this.label28.Text = "Mobile Phone";
            // 
            // numericUpDownLaptop
            // 
            this.numericUpDownLaptop.Location = new System.Drawing.Point(356, 1958);
            this.numericUpDownLaptop.Name = "numericUpDownLaptop";
            this.numericUpDownLaptop.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownLaptop.TabIndex = 165;
            this.numericUpDownLaptop.ValueChanged += new System.EventHandler(this.numericUpDownLaptop_ValueChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(377, 1824);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(57, 18);
            this.label26.TabIndex = 164;
            this.label26.Text = "Laptop";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Sitka Banner", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(89, 1761);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(613, 50);
            this.label27.TabIndex = 162;
            this.label27.Text = "Small IT and Telecommunication Equipment";
            // 
            // numericUpDownLamp
            // 
            this.numericUpDownLamp.Location = new System.Drawing.Point(356, 1677);
            this.numericUpDownLamp.Name = "numericUpDownLamp";
            this.numericUpDownLamp.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownLamp.TabIndex = 161;
            this.numericUpDownLamp.ValueChanged += new System.EventHandler(this.numericUpDownLamp_ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(337, 1543);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(137, 18);
            this.label13.TabIndex = 160;
            this.label13.Text = "Fluorescence tube";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Sitka Banner", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(349, 1479);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(111, 50);
            this.label25.TabIndex = 158;
            this.label25.Text = "Lamps";
            // 
            // numericUpDownLCDTV
            // 
            this.numericUpDownLCDTV.Location = new System.Drawing.Point(468, 1415);
            this.numericUpDownLCDTV.Name = "numericUpDownLCDTV";
            this.numericUpDownLCDTV.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownLCDTV.TabIndex = 157;
            this.numericUpDownLCDTV.ValueChanged += new System.EventHandler(this.numericUpDownLCDTV_ValueChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(444, 1281);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(147, 18);
            this.label22.TabIndex = 156;
            this.label22.Text = "LCD TV and Monitor";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Sitka Banner", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(262, 1218);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(310, 50);
            this.label23.TabIndex = 154;
            this.label23.Text = "Screens and Monitors";
            // 
            // numericUpDownCRTTV
            // 
            this.numericUpDownCRTTV.Location = new System.Drawing.Point(273, 1415);
            this.numericUpDownCRTTV.Name = "numericUpDownCRTTV";
            this.numericUpDownCRTTV.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownCRTTV.TabIndex = 153;
            this.numericUpDownCRTTV.ValueChanged += new System.EventHandler(this.numericUpDownCRTTV_ValueChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(250, 1281);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(149, 18);
            this.label24.TabIndex = 152;
            this.label24.Text = "CRT TV and Monitor";
            // 
            // numericUpDownAlkaline
            // 
            this.numericUpDownAlkaline.Location = new System.Drawing.Point(532, 1147);
            this.numericUpDownAlkaline.Name = "numericUpDownAlkaline";
            this.numericUpDownAlkaline.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownAlkaline.TabIndex = 150;
            this.numericUpDownAlkaline.ValueChanged += new System.EventHandler(this.numericUpDownAlkaline_ValueChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(550, 1013);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 18);
            this.label16.TabIndex = 149;
            this.label16.Text = "Alkaline";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Sitka Banner", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(354, 949);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(138, 50);
            this.label19.TabIndex = 147;
            this.label19.Text = "Batteries";
            // 
            // numericUpDownNickelbased
            // 
            this.numericUpDownNickelbased.Location = new System.Drawing.Point(365, 1147);
            this.numericUpDownNickelbased.Name = "numericUpDownNickelbased";
            this.numericUpDownNickelbased.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownNickelbased.TabIndex = 146;
            this.numericUpDownNickelbased.ValueChanged += new System.EventHandler(this.numericUpDownNickelbased_ValueChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(363, 1013);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(102, 18);
            this.label20.TabIndex = 145;
            this.label20.Text = "Nickel-based";
            // 
            // numericUpDownLithiumionBatteries
            // 
            this.numericUpDownLithiumionBatteries.Location = new System.Drawing.Point(186, 1147);
            this.numericUpDownLithiumionBatteries.Name = "numericUpDownLithiumionBatteries";
            this.numericUpDownLithiumionBatteries.Size = new System.Drawing.Size(105, 20);
            this.numericUpDownLithiumionBatteries.TabIndex = 143;
            this.numericUpDownLithiumionBatteries.ValueChanged += new System.EventHandler(this.numericUpDownLithiumionBatteries_ValueChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(164, 1013);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(148, 18);
            this.label21.TabIndex = 142;
            this.label21.Text = "Lithium-ion batteries";
            // 
            // numericUpDownClothesDryer
            // 
            this.numericUpDownClothesDryer.Location = new System.Drawing.Point(532, 884);
            this.numericUpDownClothesDryer.Name = "numericUpDownClothesDryer";
            this.numericUpDownClothesDryer.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownClothesDryer.TabIndex = 140;
            this.numericUpDownClothesDryer.ValueChanged += new System.EventHandler(this.numericUpDownClothesDryer_ValueChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(523, 750);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 18);
            this.label14.TabIndex = 139;
            this.label14.Text = "Clothes Dryer";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Sitka Banner", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(275, 688);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(262, 50);
            this.label15.TabIndex = 137;
            this.label15.Text = "Large equipament";
            // 
            // numericUpDownWashingmachine
            // 
            this.numericUpDownWashingmachine.Location = new System.Drawing.Point(365, 884);
            this.numericUpDownWashingmachine.Name = "numericUpDownWashingmachine";
            this.numericUpDownWashingmachine.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownWashingmachine.TabIndex = 136;
            this.numericUpDownWashingmachine.ValueChanged += new System.EventHandler(this.numericUpDownWashingmachine_ValueChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(352, 750);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(131, 18);
            this.label17.TabIndex = 135;
            this.label17.Text = "Washing machine";
            // 
            // numericUpDownDishwasher
            // 
            this.numericUpDownDishwasher.Location = new System.Drawing.Point(186, 884);
            this.numericUpDownDishwasher.Name = "numericUpDownDishwasher";
            this.numericUpDownDishwasher.Size = new System.Drawing.Size(105, 20);
            this.numericUpDownDishwasher.TabIndex = 133;
            this.numericUpDownDishwasher.ValueChanged += new System.EventHandler(this.numericUpDownDishwasher_ValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(191, 750);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(89, 18);
            this.label18.TabIndex = 132;
            this.label18.Text = "Dishwasher";
            // 
            // numericUpDownAirCond
            // 
            this.numericUpDownAirCond.Location = new System.Drawing.Point(431, 637);
            this.numericUpDownAirCond.Name = "numericUpDownAirCond";
            this.numericUpDownAirCond.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownAirCond.TabIndex = 130;
            this.numericUpDownAirCond.ValueChanged += new System.EventHandler(this.numericUpDownAirCond_ValueChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(422, 503);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(122, 18);
            this.label12.TabIndex = 129;
            this.label12.Text = "Air Condicioning";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Sitka Banner", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(148, 436);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(482, 50);
            this.label11.TabIndex = 127;
            this.label11.Text = "Temperature Exchange Equipment";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(601, 503);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 18);
            this.label8.TabIndex = 125;
            this.label8.Text = "Water boiler";
            // 
            // numericUpDownWBoiler
            // 
            this.numericUpDownWBoiler.Location = new System.Drawing.Point(601, 637);
            this.numericUpDownWBoiler.Name = "numericUpDownWBoiler";
            this.numericUpDownWBoiler.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownWBoiler.TabIndex = 126;
            this.numericUpDownWBoiler.ValueChanged += new System.EventHandler(this.numericUpDownWBoiler_ValueChanged);
            // 
            // numericUpDownFreezer
            // 
            this.numericUpDownFreezer.Location = new System.Drawing.Point(259, 637);
            this.numericUpDownFreezer.Name = "numericUpDownFreezer";
            this.numericUpDownFreezer.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownFreezer.TabIndex = 123;
            this.numericUpDownFreezer.ValueChanged += new System.EventHandler(this.numericUpDownFreezer_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(281, 503);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 18);
            this.label9.TabIndex = 122;
            this.label9.Text = "Freezer";
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(86, 637);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(105, 20);
            this.numericUpDown4.TabIndex = 120;
            this.numericUpDown4.ValueChanged += new System.EventHandler(this.numericUpDown4_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(111, 503);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 18);
            this.label10.TabIndex = 119;
            this.label10.Text = "Fridge\r\n";
            // 
            // numericUpDownMicrowave
            // 
            this.numericUpDownMicrowave.Location = new System.Drawing.Point(601, 211);
            this.numericUpDownMicrowave.Name = "numericUpDownMicrowave";
            this.numericUpDownMicrowave.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownMicrowave.TabIndex = 105;
            this.numericUpDownMicrowave.ValueChanged += new System.EventHandler(this.numericUpDownMicrowave_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(631, 240);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 18);
            this.label7.TabIndex = 116;
            this.label7.Text = "Other";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(611, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 18);
            this.label4.TabIndex = 108;
            this.label4.Text = "Microwave";
            // 
            // numericUpDownOtherSE
            // 
            this.numericUpDownOtherSE.Location = new System.Drawing.Point(601, 374);
            this.numericUpDownOtherSE.Name = "numericUpDownOtherSE";
            this.numericUpDownOtherSE.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownOtherSE.TabIndex = 117;
            this.numericUpDownOtherSE.ValueChanged += new System.EventHandler(this.numericUpDownOtherSE_ValueChanged);
            // 
            // numericUpDownPersonalCare
            // 
            this.numericUpDownPersonalCare.Location = new System.Drawing.Point(349, 374);
            this.numericUpDownPersonalCare.Name = "numericUpDownPersonalCare";
            this.numericUpDownPersonalCare.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownPersonalCare.TabIndex = 114;
            this.numericUpDownPersonalCare.ValueChanged += new System.EventHandler(this.numericUpDownPersonalCare_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(347, 240);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 18);
            this.label6.TabIndex = 113;
            this.label6.Text = "Personal Care";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(86, 374);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(105, 20);
            this.numericUpDown1.TabIndex = 111;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(78, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 18);
            this.label5.TabIndex = 110;
            this.label5.Text = "Vacuum cleaner";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(307, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(186, 18);
            this.label3.TabIndex = 107;
            this.label3.Text = "Heating and Temperature";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(75, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 18);
            this.label1.TabIndex = 106;
            this.label1.Text = "Kitchen applience";
            // 
            // numericUpDownHeatAndTemp
            // 
            this.numericUpDownHeatAndTemp.Location = new System.Drawing.Point(349, 211);
            this.numericUpDownHeatAndTemp.Name = "numericUpDownHeatAndTemp";
            this.numericUpDownHeatAndTemp.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownHeatAndTemp.TabIndex = 102;
            this.numericUpDownHeatAndTemp.ValueChanged += new System.EventHandler(this.numericUpDownHeatAndTemp_ValueChanged);
            // 
            // numericUpDownKitchenApplience
            // 
            this.numericUpDownKitchenApplience.Location = new System.Drawing.Point(87, 211);
            this.numericUpDownKitchenApplience.Name = "numericUpDownKitchenApplience";
            this.numericUpDownKitchenApplience.Size = new System.Drawing.Size(104, 20);
            this.numericUpDownKitchenApplience.TabIndex = 100;
            this.numericUpDownKitchenApplience.ValueChanged += new System.EventHandler(this.numericUpDownKitchenApplience_ValueChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Aquamarine;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(9, 9);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(48, 46);
            this.button1.TabIndex = 99;
            this.button1.Text = "<--\r\n";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Sitka Banner", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(272, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(251, 50);
            this.label2.TabIndex = 98;
            this.label2.Text = "Small Equipment\r\n";
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox25.Location = new System.Drawing.Point(356, 2098);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(104, 107);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox25.TabIndex = 178;
            this.pictureBox25.TabStop = false;
            // 
            // pictureBox24
            // 
            this.pictureBox24.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox24.Image")));
            this.pictureBox24.Location = new System.Drawing.Point(474, 2026);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(104, 107);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox24.TabIndex = 175;
            this.pictureBox24.TabStop = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox23.Image")));
            this.pictureBox23.Location = new System.Drawing.Point(239, 2026);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(104, 107);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox23.TabIndex = 172;
            this.pictureBox23.TabStop = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox22.Image")));
            this.pictureBox22.Location = new System.Drawing.Point(584, 1845);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(104, 107);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox22.TabIndex = 169;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox21.Image")));
            this.pictureBox21.Location = new System.Drawing.Point(123, 1845);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(104, 107);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox21.TabIndex = 166;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox20.Image")));
            this.pictureBox20.Location = new System.Drawing.Point(356, 1845);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(104, 107);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox20.TabIndex = 163;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(356, 1564);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(104, 107);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 159;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox18.Image")));
            this.pictureBox18.Location = new System.Drawing.Point(468, 1302);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(104, 107);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox18.TabIndex = 155;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox19.Image")));
            this.pictureBox19.Location = new System.Drawing.Point(271, 1302);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(104, 107);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox19.TabIndex = 151;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(532, 1034);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(104, 107);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 148;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox16.Image")));
            this.pictureBox16.Location = new System.Drawing.Point(363, 1034);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(104, 107);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox16.TabIndex = 144;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox17.Image")));
            this.pictureBox17.Location = new System.Drawing.Point(187, 1034);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(104, 107);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox17.TabIndex = 141;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(532, 771);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(104, 107);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 138;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(363, 771);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(104, 107);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox14.TabIndex = 134;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(187, 771);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(104, 107);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 131;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(431, 524);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(104, 107);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 128;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(601, 524);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(104, 107);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 124;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(259, 524);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(104, 107);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 121;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(87, 524);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(104, 107);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 118;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(602, 98);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(103, 107);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 104;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(601, 261);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(104, 107);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 115;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(349, 261);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(104, 107);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 112;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(87, 261);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(104, 107);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 109;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(87, 98);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(104, 107);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 103;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(349, 98);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(104, 107);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 101;
            this.pictureBox1.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Aqua;
            this.button2.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(663, 2127);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(142, 66);
            this.button2.TabIndex = 179;
            this.button2.Text = "Continuar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(834, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.pictureBox25);
            this.Controls.Add(this.numericUpDownOtherSTE);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.numericUpDownRouter);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.numericUpDownPrinter);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.numericUpDownMobilePhone);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.numericUpDownLaptop);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.numericUpDownLamp);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.numericUpDownLCDTV);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.numericUpDownCRTTV);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.numericUpDownAlkaline);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.numericUpDownNickelbased);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.numericUpDownLithiumionBatteries);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.numericUpDownClothesDryer);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.numericUpDownWashingmachine);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.numericUpDownDishwasher);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.numericUpDownAirCond);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.numericUpDownWBoiler);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.numericUpDownFreezer);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.numericUpDown4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.numericUpDownMicrowave);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.numericUpDownOtherSE);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.numericUpDownPersonalCare);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.numericUpDownHeatAndTemp);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.numericUpDownKitchenApplience);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOtherSTE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRouter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPrinter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMobilePhone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLaptop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLamp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLCDTV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCRTTV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlkaline)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNickelbased)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLithiumionBatteries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownClothesDryer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWashingmachine)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDishwasher)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAirCond)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWBoiler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFreezer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMicrowave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOtherSE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPersonalCare)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHeatAndTemp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownKitchenApplience)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.NumericUpDown numericUpDownOtherSTE;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.NumericUpDown numericUpDownRouter;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.NumericUpDown numericUpDownPrinter;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.NumericUpDown numericUpDownMobilePhone;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.NumericUpDown numericUpDownLaptop;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown numericUpDownLamp;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown numericUpDownLCDTV;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown numericUpDownCRTTV;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.NumericUpDown numericUpDownAlkaline;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown numericUpDownNickelbased;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.NumericUpDown numericUpDownLithiumionBatteries;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.NumericUpDown numericUpDownClothesDryer;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown numericUpDownWashingmachine;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.NumericUpDown numericUpDownDishwasher;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.NumericUpDown numericUpDownAirCond;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numericUpDownWBoiler;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.NumericUpDown numericUpDownFreezer;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.NumericUpDown numericUpDownMicrowave;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.NumericUpDown numericUpDownOtherSE;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.NumericUpDown numericUpDownPersonalCare;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.NumericUpDown numericUpDownHeatAndTemp;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.NumericUpDown numericUpDownKitchenApplience;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
    }
}