﻿
namespace E_Waste_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTNstart = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BTNstart
            // 
            this.BTNstart.BackColor = System.Drawing.Color.Tomato;
            this.BTNstart.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.BTNstart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BTNstart.Font = new System.Drawing.Font("MS Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNstart.Location = new System.Drawing.Point(331, 200);
            this.BTNstart.Name = "BTNstart";
            this.BTNstart.Size = new System.Drawing.Size(138, 50);
            this.BTNstart.TabIndex = 1;
            this.BTNstart.Text = "Start";
            this.BTNstart.UseVisualStyleBackColor = false;
            this.BTNstart.Click += new System.EventHandler(this.BTNstart_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::E_Waste_Calculator.Properties.Resources.ecrã;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BTNstart);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTNstart;
    }
}

