﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Waste_Calculator
{
    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var Form1 = new Form1();
            this.Hide();
            Form1.Show();
        }

        //EQUIPAMENTOS PEQUENOS
        private void numericUpDownKitchenApplience_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG /16) + (16 * (double)numericUpDownKitchenApplience.Value);
            Form3.AluminioG = (Form3.AluminioG / 3) + (3 * (double)numericUpDownKitchenApplience.Value);
            Form3.CobreG = (Form3.CobreG / 8) + (8 * (double)numericUpDownKitchenApplience.Value);
            Form3.eWasteG = (Form3.eWasteG / 1.61) + (1.61 * (double)numericUpDownKitchenApplience.Value);
            Form3.CO2G = (Form3.CO2G / 1.78) + (1.78 * (double)numericUpDownKitchenApplience.Value);

        }

        private void numericUpDownHeatAndTemp_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 133) + (133 * (double)numericUpDownHeatAndTemp.Value);
            Form3.AluminioG = (Form3.AluminioG / 350) + (350 * (double)numericUpDownHeatAndTemp.Value);
            Form3.CobreG = (Form3.CobreG / 7) + (7 * (double)numericUpDownHeatAndTemp.Value);
            Form3.eWasteG = (Form3.eWasteG / 7) + (7 * (double)numericUpDownHeatAndTemp.Value);
            Form3.CO2G = (Form3.CO2G / 7.74) + (7.74 * (double)numericUpDownHeatAndTemp.Value);

        }

        private void numericUpDownMicrowave_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 1904) + (1904 * (double)numericUpDownMicrowave.Value);
            Form3.AluminioG = (Form3.AluminioG / 612) + (612 * (double)numericUpDownMicrowave.Value);
            Form3.CobreG = (Form3.CobreG / 1278) + (1278 * (double)numericUpDownMicrowave.Value);
            Form3.eWasteG = (Form3.eWasteG / 13.3) + (13.3 * (double)numericUpDownMicrowave.Value);
            Form3.CO2G = (Form3.CO2G / 15.03) + (15.03 * (double)numericUpDownMicrowave.Value);

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 2418) + (2418 * (double)numericUpDown1.Value);
            Form3.AluminioG = (Form3.AluminioG / 365) + (365 * (double)numericUpDown1.Value);
            Form3.CobreG = (Form3.CobreG / 49) + (49 * (double)numericUpDown1.Value);
            Form3.eWasteG = (Form3.eWasteG / 4.05) + (4.05 * (double)numericUpDown1.Value);
            Form3.CO2G = (Form3.CO2G / 4.48) +  + (4.48 * (double)numericUpDown1.Value);

        }

        private void numericUpDownPersonalCare_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 174) + (174 * (double)numericUpDownPersonalCare.Value);
            Form3.AluminioG = (Form3.AluminioG / 21) + (21 * (double)numericUpDownPersonalCare.Value);
            Form3.CobreG = (Form3.CobreG / 44) + (44 * (double)numericUpDownPersonalCare.Value);
            Form3.eWasteG = (Form3.eWasteG / 0.4) + (0.4 * (double)numericUpDownPersonalCare.Value);
            Form3.CO2G = (Form3.CO2G / 0.44) + (0.44 * (double)numericUpDownPersonalCare.Value);

        }

        private void numericUpDownOtherSE_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 1484) + (1484 * (double)numericUpDownOtherSE.Value);
           
            Form3.CobreG = (Form3.CobreG / 133) + (133 * (double)numericUpDownOtherSE.Value);
            Form3.eWasteG = (Form3.eWasteG / 7) + (7 * (double)numericUpDownOtherSE.Value);
            Form3.CO2G = (Form3.CO2G / 7.74) + (7.74 * (double)numericUpDownOtherSE.Value);

        }
        //EQUIPAMENTOS DE TROCA DE TEMPERATURA
        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 13275) + (13275 * (double)numericUpDown4.Value);
            Form3.AluminioG = (Form3.AluminioG / 945) + (945 * (double)numericUpDown4.Value);
            Form3.CobreG = (Form3.CobreG / 765) + (765 * (double)numericUpDown4.Value);
            Form3.eWasteG = (Form3.eWasteG / 45) + (45 * (double)numericUpDown4.Value);
            Form3.CO2G = (Form3.CO2G / 51) + (51 * (double)numericUpDown4.Value);


        }

        private void numericUpDownFreezer_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 11970) + (11970 * (double)numericUpDownFreezer.Value);
            Form3.AluminioG = (Form3.AluminioG / 1890) + (1890 * (double)numericUpDownFreezer.Value);
            Form3.CobreG = (Form3.CobreG / 765)  + (765 * (double)numericUpDownFreezer.Value);
            Form3.eWasteG = (Form3.eWasteG / 345) + (345 * (double)numericUpDownFreezer.Value);
            Form3.CO2G = (Form3.CO2G / 51) + (51 * (double)numericUpDownFreezer.Value);

        }

        private void numericUpDownAirCond_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 6922) + (6922 * (double)numericUpDownAirCond.Value);
            Form3.AluminioG = (Form3.AluminioG / 2025)  + (2025 * (double)numericUpDownAirCond.Value);
            Form3.CobreG = (Form3.CobreG / 8285) + (8285 * (double)numericUpDownAirCond.Value);
            Form3.eWasteG = (Form3.eWasteG / 36.82) + (36.82 * (double)numericUpDownAirCond.Value);
            Form3.CO2G = (Form3.CO2G / 68) + (68 * (double)numericUpDownAirCond.Value);

        }

        private void numericUpDownWBoiler_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 13001) + (13001 * (double)numericUpDownWBoiler.Value);
            Form3.AluminioG = (Form3.AluminioG / 691) + (691 * (double)numericUpDownWBoiler.Value);
            Form3.CobreG = (Form3.CobreG / 401) + (401 * (double)numericUpDownWBoiler.Value);
            Form3.eWasteG = (Form3.eWasteG / 22.3)  + (22.3 * (double)numericUpDownWBoiler.Value);
            Form3.CO2G = (Form3.CO2G / 24.65) + (24.65 * (double)numericUpDownWBoiler.Value);

        }
        //EQUIPAMENTOS GRANDES
        private void numericUpDownDishwasher_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 10714) + (10714 * (double)numericUpDownDishwasher.Value);
            Form3.AluminioG = (Form3.AluminioG / 101) + (101 * (double)numericUpDownDishwasher.Value);
            Form3.CobreG = (Form3.CobreG / 404) + (404 * (double)numericUpDownDishwasher.Value);
            Form3.eWasteG = (Form3.eWasteG / 50.54) + (50.54 * (double)numericUpDownDishwasher.Value);
            Form3.CO2G = (Form3.CO2G / 154)  + (154 * (double)numericUpDownDishwasher.Value);

        }

        private void numericUpDownWashingmachine_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 107009) + (107009 * (double)numericUpDownWashingmachine.Value);
            Form3.AluminioG = (Form3.AluminioG / 2168) + (2168 * (double)numericUpDownWashingmachine.Value);
            Form3.CobreG = (Form3.CobreG / 920) + (920 * (double)numericUpDownWashingmachine.Value);
            Form3.eWasteG = (Form3.eWasteG / 65.7) + (65.7 * (double)numericUpDownWashingmachine.Value);
            Form3.CO2G = (Form3.eWasteG / 156) + (156 * (double)numericUpDownWashingmachine.Value);

        }

        private void numericUpDownClothesDryer_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 19710) + (19710 * (double)numericUpDownClothesDryer.Value);
            Form3.AluminioG = (Form3.AluminioG / 2431) + (2431 * (double)numericUpDownClothesDryer.Value);
            Form3.CobreG = (Form3.CobreG / 3285) + (3285 * (double)numericUpDownClothesDryer.Value);
            Form3.eWasteG = (Form3.eWasteG / 65.7) + (65.7 * (double)numericUpDownClothesDryer.Value);
            Form3.CO2G = (Form3.CO2G / 56) + (56 * (double)numericUpDownClothesDryer.Value);

        }

        //BATERIAS
        private void numericUpDownLithiumionBatteries_ValueChanged(object sender, EventArgs e)
        {
            
            Form3.AluminioG = (Form3.AluminioG / 1) + (1 * (double)numericUpDownLithiumionBatteries.Value);
            Form3.CobreG = (Form3.CobreG / 3) + (3 * (double)numericUpDownLithiumionBatteries.Value);
            Form3.eWasteG = (Form3.eWasteG / 0.015) + (0.015 * (double)numericUpDownLithiumionBatteries.Value);
            Form3.CO2G = (Form3.CO2G / 0.073) + (0.073 * (double)numericUpDownLithiumionBatteries.Value);

        }

        private void numericUpDownNickelbased_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 1) + (1 * (double)numericUpDownNickelbased.Value);
           
            Form3.CobreG = (Form3.CobreG / 0.1) + (0.1 * (double)numericUpDownNickelbased.Value);
            Form3.eWasteG = (Form3.eWasteG / 0.023) + (0.023 * (double)numericUpDownNickelbased.Value);
            Form3.CO2G = (Form3.CO2G / 0.107) + (0.107 * (double)numericUpDownNickelbased.Value);

        }

        private void numericUpDownAlkaline_ValueChanged(object sender, EventArgs e)
        {
            
          
            Form3.eWasteG = (Form3.eWasteG / 0.023) + (0.023 * (double)numericUpDownAlkaline.Value);
            Form3.CO2G = (Form3.CO2G / 0.107) + (0.107 * (double)numericUpDownAlkaline.Value);

        }

        //TELAS E MONITORES
        private void numericUpDownCRTTV_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 4428) + (4428 * (double)numericUpDownCRTTV.Value);
           
            Form3.eWasteG = (Form3.eWasteG / 18) + (18 * (double)numericUpDownCRTTV.Value);
            Form3.CO2G = (Form3.CO2G / 63) + (63 * (double)numericUpDownCRTTV.Value);

        }

        private void numericUpDownLCDTV_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 6237) + (6237 * (double)numericUpDownLCDTV.Value);
            Form3.AluminioG = (Form3.AluminioG / 18) + (18 * (double)numericUpDownLCDTV.Value);
            Form3.CobreG = (Form3.CobreG / 326) + (326 * (double)numericUpDownLCDTV.Value);
            Form3.eWasteG = (Form3.eWasteG / 18.13) + (18.13 * (double)numericUpDownLCDTV.Value);
            Form3.CO2G = (Form3.CO2G / 20.04) + (20.04 * (double)numericUpDownLCDTV.Value);

        }

        //LAMPADAS
        private void numericUpDownLamp_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 2) + (2 * (double)numericUpDownLamp.Value);
            
            Form3.eWasteG = (Form3.eWasteG / 0.14) + (0.14 * (double)numericUpDownLamp.Value);
            Form3.CO2G = (Form3.CO2G / 0.01) + (0.01 * (double)numericUpDownLamp.Value);

        }
        //TELECOMUNICAÇÕES
        private void numericUpDownMobilePhone_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 59) + (59 * (double)numericUpDownMobilePhone.Value);
            Form3.AluminioG = (Form3.AluminioG / 3) + (3 * (double)numericUpDownMobilePhone.Value);
            Form3.CobreG = (Form3.CobreG / 13) + (13 * (double)numericUpDownMobilePhone.Value);
            Form3.eWasteG = (Form3.eWasteG / 0.013) + (0.013 * (double)numericUpDownMobilePhone.Value);
            Form3.CO2G = (Form3.CO2G / 0.014) + (0.014 * (double)numericUpDownMobilePhone.Value);

        }

        private void numericUpDownLaptop_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 1140)  + (1140 * (double)numericUpDownLaptop.Value);
            Form3.AluminioG = (Form3.AluminioG / 682) + (682 * (double)numericUpDownLaptop.Value);
            Form3.CobreG = (Form3.CobreG / 122) + (122 * (double)numericUpDownLaptop.Value);
            Form3.eWasteG = (Form3.eWasteG / 2.9) + (2.9 * (double)numericUpDownLaptop.Value);
            Form3.CO2G = (Form3.PlasticoG / 3.21) + (3.21 * (double)numericUpDownLaptop.Value);

        }

        private void numericUpDownPrinter_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 3666) + (3666 * (double)numericUpDownPrinter.Value);
            
            Form3.CobreG = (Form3.CobreG / 126) + (126 * (double)numericUpDownPrinter.Value);
            Form3.eWasteG = (Form3.eWasteG / 6) + (6 * (double)numericUpDownPrinter.Value);
            Form3.CO2G = (Form3.CO2G / 15.69) + (15.69 * (double)numericUpDownPrinter.Value);

        }

        private void numericUpDownRouter_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 580) + (580 * (double)numericUpDownRouter.Value);
            
            Form3.eWasteG = (Form3.eWasteG / 2.05) + (2.05 * (double)numericUpDownRouter.Value);
            Form3.CO2G = (Form3.CO2G / 2.27) + (2.27 * (double)numericUpDownRouter.Value);

        }

        private void numericUpDownOtherSTE_ValueChanged(object sender, EventArgs e)
        {
            Form3.PlasticoG = (Form3.PlasticoG / 63) + (63 * (double)numericUpDownOtherSTE.Value);
            Form3.AluminioG = (Form3.AluminioG / 3) + (3 * (double)numericUpDownOtherSTE.Value);
            Form3.CobreG = (Form3.CobreG / 14) + (14 * (double)numericUpDownOtherSTE.Value);
            Form3.eWasteG = (Form3.eWasteG / 0.14) + (0.14 * (double)numericUpDownOtherSTE.Value);
            Form3.CO2G = (Form3.CO2G / 0.16) + (0.16 * (double)numericUpDownOtherSTE.Value);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var Form3 = new Form3();
            this.Hide();
            Form3.Show();
        }
    }
}
