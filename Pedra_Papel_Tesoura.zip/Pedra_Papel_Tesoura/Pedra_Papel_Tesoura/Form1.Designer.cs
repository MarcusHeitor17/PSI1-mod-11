﻿namespace Pedra_Papel_Tesoura
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Digiteseunome = new Label();
            txtNome = new TextBox();
            button1 = new Button();
            button2 = new Button();
            HelpButton = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Lime;
            label1.Location = new Point(190, 9);
            label1.Name = "label1";
            label1.Size = new Size(408, 45);
            label1.TabIndex = 0;
            label1.Text = "PEDRA PAPEL E TESOURA";
            // 
            // Digiteseunome
            // 
            Digiteseunome.AutoSize = true;
            Digiteseunome.Location = new Point(154, 115);
            Digiteseunome.Name = "Digiteseunome";
            Digiteseunome.Size = new Size(99, 15);
            Digiteseunome.TabIndex = 1;
            Digiteseunome.Text = "Digite Seu Nome:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(259, 112);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(282, 23);
            txtNome.TabIndex = 2;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(128, 255, 128);
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(628, 246);
            button1.Name = "button1";
            button1.Size = new Size(160, 100);
            button1.TabIndex = 3;
            button1.Text = "Avançar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // button2
            // 
            button2.Location = new Point(449, 211);
            button2.Name = "button2";
            button2.Size = new Size(8, 8);
            button2.TabIndex = 4;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = true;
            // 
            // HelpButton
            // 
            HelpButton.BackColor = Color.FromArgb(128, 255, 128);
            HelpButton.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            HelpButton.Location = new Point(12, 246);
            HelpButton.Name = "HelpButton";
            HelpButton.Size = new Size(160, 100);
            HelpButton.TabIndex = 5;
            HelpButton.Text = "Como jogar";
            HelpButton.UseVisualStyleBackColor = false;
            HelpButton.Click += HelpButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(800, 450);
            Controls.Add(HelpButton);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtNome);
            Controls.Add(Digiteseunome);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label Digiteseunome;
        private TextBox txtNome;
        private Button button1;
        private Button button2;
        private Button HelpButton;
    }
}