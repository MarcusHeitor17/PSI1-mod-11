﻿namespace Pedra_Papel_Tesoura
{
    partial class PPT
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PPT));
            BTPedra = new Button();
            BTPapel = new Button();
            BTTesoura = new Button();
            PICJogador = new PictureBox();
            PICcpu = new PictureBox();
            LBDescricaoCPU = new Label();
            LBDescricaoJogador = new Label();
            LBPTJogador = new Label();
            LBPTCPU = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)PICJogador).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PICcpu).BeginInit();
            SuspendLayout();
            // 
            // BTPedra
            // 
            BTPedra.BackColor = Color.White;
            BTPedra.BackgroundImage = (Image)resources.GetObject("BTPedra.BackgroundImage");
            BTPedra.BackgroundImageLayout = ImageLayout.Stretch;
            BTPedra.Location = new Point(25, 277);
            BTPedra.Name = "BTPedra";
            BTPedra.Size = new Size(120, 120);
            BTPedra.TabIndex = 0;
            BTPedra.Tag = "0";
            BTPedra.UseVisualStyleBackColor = false;
            BTPedra.Click += ClickJogada;
            // 
            // BTPapel
            // 
            BTPapel.BackColor = Color.White;
            BTPapel.BackgroundImage = (Image)resources.GetObject("BTPapel.BackgroundImage");
            BTPapel.BackgroundImageLayout = ImageLayout.Stretch;
            BTPapel.Location = new Point(209, 277);
            BTPapel.Name = "BTPapel";
            BTPapel.Size = new Size(120, 120);
            BTPapel.TabIndex = 1;
            BTPapel.Tag = "1";
            BTPapel.UseVisualStyleBackColor = false;
            BTPapel.Click += ClickJogada;
            // 
            // BTTesoura
            // 
            BTTesoura.BackColor = Color.White;
            BTTesoura.BackgroundImage = (Image)resources.GetObject("BTTesoura.BackgroundImage");
            BTTesoura.BackgroundImageLayout = ImageLayout.Stretch;
            BTTesoura.Location = new Point(389, 277);
            BTTesoura.Name = "BTTesoura";
            BTTesoura.Size = new Size(120, 120);
            BTTesoura.TabIndex = 2;
            BTTesoura.Tag = "2";
            BTTesoura.UseVisualStyleBackColor = false;
            BTTesoura.Click += ClickJogada;
            // 
            // PICJogador
            // 
            PICJogador.BorderStyle = BorderStyle.Fixed3D;
            PICJogador.Location = new Point(25, 38);
            PICJogador.Name = "PICJogador";
            PICJogador.Size = new Size(150, 150);
            PICJogador.SizeMode = PictureBoxSizeMode.StretchImage;
            PICJogador.TabIndex = 3;
            PICJogador.TabStop = false;
            // 
            // PICcpu
            // 
            PICcpu.BorderStyle = BorderStyle.Fixed3D;
            PICcpu.Location = new Point(359, 38);
            PICcpu.Name = "PICcpu";
            PICcpu.Size = new Size(150, 150);
            PICcpu.SizeMode = PictureBoxSizeMode.StretchImage;
            PICcpu.TabIndex = 4;
            PICcpu.TabStop = false;
            // 
            // LBDescricaoCPU
            // 
            LBDescricaoCPU.AutoSize = true;
            LBDescricaoCPU.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            LBDescricaoCPU.Location = new Point(467, 9);
            LBDescricaoCPU.Name = "LBDescricaoCPU";
            LBDescricaoCPU.Size = new Size(42, 21);
            LBDescricaoCPU.TabIndex = 5;
            LBDescricaoCPU.Text = "CPU";
            // 
            // LBDescricaoJogador
            // 
            LBDescricaoJogador.AutoSize = true;
            LBDescricaoJogador.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            LBDescricaoJogador.Location = new Point(25, 9);
            LBDescricaoJogador.Name = "LBDescricaoJogador";
            LBDescricaoJogador.Size = new Size(0, 21);
            LBDescricaoJogador.TabIndex = 6;
            LBDescricaoJogador.Click += LBDescricaoJogador_Click;
            // 
            // LBPTJogador
            // 
            LBPTJogador.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            LBPTJogador.Location = new Point(197, 105);
            LBPTJogador.Name = "LBPTJogador";
            LBPTJogador.Size = new Size(40, 20);
            LBPTJogador.TabIndex = 7;
            LBPTJogador.Text = "0";
            LBPTJogador.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // LBPTCPU
            // 
            LBPTCPU.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            LBPTCPU.Location = new Point(298, 105);
            LBPTCPU.Name = "LBPTCPU";
            LBPTCPU.Size = new Size(40, 20);
            LBPTCPU.TabIndex = 8;
            LBPTCPU.Text = "0";
            LBPTCPU.TextAlign = ContentAlignment.MiddleCenter;
            LBPTCPU.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(233, 69);
            label1.Name = "label1";
            label1.Size = new Size(70, 21);
            label1.TabIndex = 9;
            label1.Text = "PLACAR";
            // 
            // PPT
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(128, 255, 128);
            ClientSize = new Size(532, 450);
            Controls.Add(label1);
            Controls.Add(LBPTCPU);
            Controls.Add(LBPTJogador);
            Controls.Add(LBDescricaoJogador);
            Controls.Add(LBDescricaoCPU);
            Controls.Add(PICcpu);
            Controls.Add(PICJogador);
            Controls.Add(BTTesoura);
            Controls.Add(BTPapel);
            Controls.Add(BTPedra);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "PPT";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "PPT";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)PICJogador).EndInit();
            ((System.ComponentModel.ISupportInitialize)PICcpu).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BTPedra;
        private Button BTPapel;
        private Button BTTesoura;
        private PictureBox PICJogador;
        private PictureBox PICcpu;
        private Label LBDescricaoCPU;
        private Label LBDescricaoJogador;
        private Label LBPTJogador;
        private Label LBPTCPU;
        private Label label1;
    }
}