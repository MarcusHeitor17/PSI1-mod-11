﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pedra_Papel_Tesoura
{
    internal class Pontuacao
    {
        public int PontosJogador { get; private set; }
        public int PontosCPU { get; private set; }

        public void AdicionarPontosJogador()
        {
            PontosJogador++;
        }

        public void AdicionarPontosCPU()
        {
            PontosCPU++;
        }



    }

}
