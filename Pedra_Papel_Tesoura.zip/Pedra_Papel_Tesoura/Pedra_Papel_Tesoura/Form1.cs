﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pedra_Papel_Tesoura
{
    public partial class Form1 : Form
    {

       

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string nomeUtilizador = txtNome.Text;
            try
            {
                nomeUtilizador = Convert.ToString(txtNome.Text);
                if (nomeUtilizador.Any(char.IsDigit))
                {
                    throw new Exception();

                }
                MessageBox.Show("Bem-vindo(a), " + nomeUtilizador + "!");
            }
            catch (Exception)
            {
                MessageBox.Show("Nome inválido, não é permitido números.");
            }

            if (!nomeUtilizador.Any(char.IsDigit))
            {
                // Nome não contém números, então pode passar para a próxima cena
                PPT Form2 = new PPT();
                Form2.NomeUtilizador = nomeUtilizador; // atribui o nome à propriedade NomeUtilizador do Form2
                Form2.Show();
                this.Hide();
            }
            else
            {
                // Nome contém números, exibir mensagem de erro
                MessageBox.Show("Tente inserir o nome sem números.");
            }
        }  
 

        private void HelpButton_Click(object sender, EventArgs e)
        {
            NovaTela novaTela = new NovaTela();
            novaTela.Exibir();
        }
    }
}
