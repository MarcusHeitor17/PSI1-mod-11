﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pedra_Papel_Tesoura
{
    internal class NovaTela
    {
        public void Exibir()
        {
            Form novaForm = new Form();
            novaForm.Text = "Tela de Ajuda";
            novaForm.ShowDialog();

            Label label = new Label();
            label.Text = "Para jogar basta colocar seu nome na caixa de Texto ao centro da tela, depois clicar no botão *Avançar*\n\nAs regras são bem simples, você irá jogar com uma CPU, basta selecionar 1 das 3 opções abaixo (Pedra, Papel ou Tesoura) para jogar e ver seu resultado.";
            label.Dock = DockStyle.Fill;
            novaForm.Controls.Add(label);

            novaForm.ShowDialog();
        }
    }
}
