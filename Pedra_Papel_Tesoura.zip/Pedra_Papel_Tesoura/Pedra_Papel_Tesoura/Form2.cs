namespace Pedra_Papel_Tesoura

{
    public partial class PPT : Form
    {
        public string NomeUtilizador { get; set; }
        public Image[] imgCPU = new Image[]//Array em que fica armazenado as imagens de jogada da CPU
         {
          Properties.Resources.PEDRACPU,
          Properties.Resources.PapeCPU,
          Properties.Resources.TesouraCPU,
         };


        //Chamando a Class1

        public PPT()
        {
            InitializeComponent();


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LBDescricaoJogador.Text = NomeUtilizador; 
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }


        private void ClickJogada(object sender, EventArgs e)//Evento do Click dos 3 bot�es
        {
            Button bt = (Button)sender;
            PICJogador.Image = bt.BackgroundImage;//Transfere a imagem do bot�o selecionado para a "foto" do utilizador 
            Jogada JogadaJogador = RetornaJogadaDoJogador(Convert.ToInt32(bt.Tag));//Armazena Jogada do Jogador e converte para inteiro porque a que esta sendo chamado dos objetos s�o as Tags que s�o n�meros.
            Jogada JogadaCPU = RetornaJogadaDaCPU();
            Resultado resultado = RetornaoVencedor(JogadaJogador, JogadaCPU);//Compara o Resultado do Jogador com o da CPU

            if (resultado == Resultado.CPUV)
            {
                LBPTCPU.Text = (int.Parse(LBPTCPU.Text) + 1).ToString();//Adicina +1 valor na Label do placar da CPU
            }
            else if (resultado == Resultado.JogadorV)
            {
                LBPTJogador.Text = (int.Parse(LBPTJogador.Text) + 1).ToString();//Adicina +1 valor na Label do placar do Player
            }
        }



        private Resultado RetornaoVencedor(Jogada Jogador, Jogada CPU)//Metodo dos Resultados
        {
            if (Jogador == Jogada.Pedra)
            {
                if (CPU == Jogada.Papel)
                {
                    return Resultado.CPUV;

                }
                else if (CPU == Jogada.Tesoura)
                {
                    return Resultado.JogadorV;
                }

            }
            else if (Jogador == Jogada.Papel)
            {
                if (CPU == Jogada.Tesoura)
                {
                    return Resultado.CPUV;

                }
                else if (CPU == Jogada.Pedra)
                {
                    return Resultado.JogadorV;
                }

            }
            else
            {
                if (CPU == Jogada.Pedra)
                {
                    return Resultado.CPUV;

                }
                else if (CPU == Jogada.Papel)
                {
                    return Resultado.JogadorV;
                }

            }
            return Resultado.Empate;
        }
        private Jogada RetornaJogadaDoJogador(int escolha)//Retornando a jogada do jogador
        {
            return (Jogada)escolha;
        }

        private Jogada RetornaJogadaDaCPU()//Retornando a jogada da CPU
        {
            Random aleatorio = new Random();//v�riavel criada usando o m�todo Random que Randomifica fun��es inseridas a v�riavel.
            int escolha = aleatorio.Next(3);//Faz o sorteio de 3 n�meros sendo eles 0 1 e 2
            PICcpu.Image = imgCPU[escolha];//faz com que o valor sorteado no Next(3) imprima as imagens da Array imgCPU
            return (Jogada)escolha;//Retorna as Jogadas do enum "Jogada" (Pedra, Papel e Tesoura
        }

        private void LBDescricaoJogador_Click(object sender, EventArgs e)
        {

        }
    }

    enum Jogada
    {
        Pedra = 0,
        Papel = 1,
        Tesoura = 2
    }//Enumerador das 3 jogadas

    enum Resultado
    {
        JogadorV,
        CPUV,
        Empate

    }//Enumerador dos 2 resultados poss�veis

}